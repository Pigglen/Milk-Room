# Pumpkin Paradise
Pumpkin Paradise.
![screenshot](https://cdn.discordapp.com/attachments/632604108024578059/633333071114141696/unknown.png)
# Table of Contents
TODO: Optionally, include a table of contents in order to allow other people to quickly naviagte especially long or detailed READMEs.

## Getting Started
These instructions will get you a copy of the project up and running on your local machine. See deployment for notes on how to deploy the project on a live system.

### Prerequisites
(Preperatrion to install)

### Installation
Installation is the next section in an effective README. Tell other users how to install your project locally. Optionally, include a gif to make the process even more clear for other people.

## Usage
TODO: The next section is usage, in which you instruct other people on how to use your project after they’ve installed it. This would also be a good place to include screenshots of your project in action.

## Running the tests
How to test wheather the product works

## Deployment
Add additional notes about how to deploy this on a live system

## Built With
* List of things used to build product

## Contributing
Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us.

Larger projects often have sections on contributing to their project, in which contribution instructions are outlined. Sometimes, this is a separate file. If you have specific contribution preferences, explain them so that other developers know how to best contribute to your work. To learn more about how to help others contribute, check out the guide for (setting guidelines for repository contributors)[https://help.github.com/articles/setting-guidelines-for-repository-contributors/].

## Versionin
Say what versioning method you use.

example:
We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/USER/REPO/tags).

## Authors
* **AuthorName** - *What they do* - [USER](https://github.com/USER)
* **AuthorName** - *What they do* - [USER](https://github.com/USER)
* **AuthorName** - *What they do* - [USER](https://github.com/USER)

See also the list of [contributors](https://github.com/USER/REPO/contributors) who participated in this project.

## License
TODO: Finally, include a section for the license of your project. For more information on choosing a license, check out GitHub’s [licensing guide](http://choosealicense.com/)!


## Acknowledgments
* [README Template](https://github.com/tumblenet/repository-template) by [tumble1999](github.com/tumble1999]

* Hat tip to anyone who's code was used
* Inspiration
* etc
