const express = require('express');
var app = express();

//app.use(express.static(global.appDir));

module.exports = app;